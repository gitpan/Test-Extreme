use strict;
use Test::Extreme;

run_tests_as_script 'Test::Extreme'; 
